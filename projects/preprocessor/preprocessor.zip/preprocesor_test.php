<?php
require_once('/simpletest/autorun.php');

class TestOfLogging extends UnitTestCase {
    function testLogCreatesNewFileOnFirstMessage() {
       // $log = new Cache();
        $this->assertFalse(true);
     }
}
?>